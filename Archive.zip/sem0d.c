#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define F77(a) d ## a ## _
typedef int INT;
typedef double R;

void F77(steqr)(char *, int *, R *, R *, R *, int *, R *, int *);

/*  0<=i<=m-1, 0<=j<=n-1  without specifying

    i,                            j
    i,   j

    i,                            0            i<m-1
    i,   n 
    i+1, n+1
*/

void LegendMat(INT n, R **a, R **b, R **U)
{ INT i, j, k, info;
  R s, t; 
	
/*  basis  
    phi[k] = (L[k]-L[k-2])/sqrt(4*k-2)  2<=k<=N
           = (1-x)/2                      k = 0                            
           = (1+x)/2                      k = 1
*/                                                                         

   *U = (R *) malloc((n-1)*(n/2)*sizeof(R));
   *b = (R *) malloc((3*n+5)*sizeof(R));
   
   (*b)[0] =  2./3.;
   (*b)[1] =  1./3.;
   (*b)[2] =  1./3.;
   (*b)[3] =  2./3.;

   (*b) += 4;
   i  = n/2;
   for ( k=2; k<=n; k++ ) { /*  0,   n/2-1;   n/2,     n-2   */ 
   	   j       = k/2+(k%2?i-1:-1);
   	   	
   	   (*b)[j] = .5/((k+.5)*(k-1.5));
   	   
   	   if  ( k<=n-2 )       /*  n-1, n+n/2-2; n+n/2-1, 2*n-3 */
   	   (*b)[n-1+j] = -.25/(sqrt((k-.5)*(k+1.5))*(k+.5));
   }

   
   /* symmetic tridiagonal eigenvalues and eigenvectors
      calling the fortran interface
   */
   --n;
   if ( n>=1 ) F77(steqr)("I", &i, *b,   *b+n,   *U,   &n, *b+2*n, &info);
   if ( n>=2 ) F77(steqr)("I", &j, *b+i, *b+i+n, *U+i, &n, *b+2*n, &info);
   
   /* (L0-L1)/2 (L0+L1)/2 (L2-L0)/sqrt(6) (L3-L1)/sqrt(10) */
   *b += n;
   
   s = -1./sqrt(6.);
   for ( k=0; k<i; k++ ) {
   	   t         = s*(*U)[k*n];
   	   (*b)[k]   = t;
   	   (*b)[k+n] = t;
   }
   
   s = 1./sqrt(90.);
   for ( k=i; k<n; k++ ) {
   	   t         = s*(*U)[i+(k-i)*n];
   	   (*b)[k]   =  t;
   	   (*b)[k+n] = -t;
   }
   
   *a  = *b+2*n;
   *b -= n+4;
     
   (*a)[0] =  .5;
   (*a)[1] = -.5;
   (*a)[2] = -.5;
   (*a)[3] =  .5;
   
   return;                                                                     
}                                                                            

void assemble1d(int m, int n, R *h, R *a, R *b, int **iu, int **ju, R **vu, 
                int **iv, int **jv, R **vv)
{ int i, j, k, p, q, info;
  
  p   = m*n-1;
  q   = m*(n+2)-(m>1?5:3);
  *iu = (INT *) malloc((p+2)*sizeof(INT));
  *ju = (INT *) malloc(q*sizeof(INT));
  *vu = (R   *) malloc(q*sizeof(R));
  
  (*iu)[0] = p;
  (*iu)++;
  (*iu)[0] = 0;
  p = q = 0;
  
  for ( i=0; i<m;   i++ ) 
  for ( j=0; j<n-1; j++ ) {
  	
      (*ju)[q]   = p;
      (*vu)[q++] = 1./h[i];
      (*iu)[++p] = q;
  }
  
  for ( i=0; i<m-1; i++ ) {
      if  ( i>0 ) {
          (*ju)[q]   = m*(n-1)+i-1;
          (*vu)[q++] = a[2]/h[i];
      }
      
      (*ju)[q]   = m*(n-1)+i;
      (*vu)[q++] = a[3]/h[i]+a[0]/h[i+1];
      
      if  ( i<m-2 ) {
          (*ju)[q]   = m*(n-1)+i+1;
          (*vu)[q++] = a[1]/h[i+1];
      }
      
      (*iu)[++p] = q;
  }
  (*iu)--;
   printf("nnz(S) = [%d, %d]\n",q,m*(n+2)-(m>1?5:3));
  
  p   = m*n-1;
  q   = 5*m*n-2*m-4*n+1-(m>1?2:0);
  *iv = (INT *) malloc((p+2)*sizeof(INT));
  *jv = (INT *) malloc(q*sizeof(INT));
  *vv = (R   *) malloc(q*sizeof(R));
  
  (*iv)[0] = p;
  (*iv)++;
  (*iv)[0] = 0;
  p = q = 0;
  
  for ( i=0; i<m;   i++ ) 
  for ( j=0; j<n-1; j++ ) {
  	
      (*jv)[q]   = p;
      (*vv)[q++] = b[j+4]*h[i];
      
      if  ( i>0 ) {
          (*jv)[q]   = m*(n-1)+(i-1);
          (*vv)[q++] = b[j+3+n]*h[i];
      }
      
      if  ( i<m-1 ) {
          (*jv)[q]   = m*(n-1)+i;
          (*vv)[q++] = b[j+2+2*n]*h[i];
      }
      
      (*iv)[++p] = q;
  }
  
  for ( i=0; i<m-1; i++ ) {
  	  for ( j=0; j<n-1; j++ ) {/* i */
          (*jv)[q]   = i*(n-1)+j;
          (*vv)[q++] = b[j+2+2*n]*h[i];
      }
      
  	  for ( j=0; j<n-1; j++ ) {/* i+1 */
          (*jv)[q]   = (i+1)*(n-1)+j;
          (*vv)[q++] = b[j+3+n]*h[i+1];
      }
      
      if ( i>0 ) {
          (*jv)[q]   = m*(n-1)+i-1;
          (*vv)[q++] = b[2]*h[i];
      }
      
      (*jv)[q]   = m*(n-1)+i;
      (*vv)[q++] = b[3]*h[i]+b[0]*h[i+1];
      
      if ( i<m-2 ) {
          (*jv)[q]   = m*(n-1)+i+1;
          (*vv)[q++] = b[2]*h[i+1];
      }
      
      (*iv)[++p] = q;
  }
  (*iv)--;
  printf("nnz(M) = [%d, %d]\n",q,5*m*n-2*m-4*n+1-(m>1?2:0));
  
}   


int main(int argc, char *argv[])
{
	int i, j, k, m=2, n=10;
	
	if (argc>1) m = atoi(argv[1]);
	if (argc>2) n = atoi(argv[2]);
    
    R *h = (R *) malloc(m*sizeof(R));
    
    for ( i=0; i<m; i++ ) h[i] = 2./m;
    
    for ( i=0; i<(argc-3<m?argc-3:m); i++ ) h[i] = atof(argv[i+3]);
	
	for ( i=0; i<m; i++ ) h[i] *= 0.5;
	
	R *a, *b, *V;
	
	LegendMat(n, &a, &b, &V);
	
	int *iu, *ju, *iv, *jv;
	R   *vu, *vv;
	
	assemble1d(m, n, h, a, b, &iu, &ju, &vu, &iv, &jv, &vv);
	
	FILE *fp=fopen("stiff","w+");
	for ( j=0; j<iu[0]; j++ )
	for ( k=iu[j+1]; k<iu[j+2]; k++ )
	    fprintf(fp,"%4d %4d %.16g\n",j,ju[k],vu[k]);
    fclose(fp);
	
	FILE *fd=fopen("mass","w+");
	for ( j=0; j<iv[0]; j++ ) 
	for ( k=iv[j+1]; k<iv[j+2]; k++ )
	    fprintf(fd,"%4d %4d %.16g\n",j,jv[k],vv[k]);
    fclose(fd);
    
    free(V);
    free(b);
    free(iu);
    free(ju);
    free(vu);
    free(iv);
    free(jv);
    free(vv);
}